﻿import gradio as gr
from agent import ChaohaiXiawangAgent
a = ChaohaiXiawangAgent()
gr.ChatInterface(lambda msg,_: a.chat(msg)).launch()
