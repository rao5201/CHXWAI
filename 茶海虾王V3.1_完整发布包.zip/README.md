﻿# 茶海虾王 V3.1
AI 助手 | 本地模型 + 云端模型 | 知识库记忆 | 插件系统
使用方法：
pip install ollama openai tenacity
python agent.py
