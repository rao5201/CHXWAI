@echo off
pip install pyinstaller
pyinstaller --onefile agent.py
pause
