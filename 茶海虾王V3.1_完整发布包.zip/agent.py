﻿import os
import json
import re
import random
import logging
from pathlib import Path
from typing import Dict, List, Optional, Callable, Any, Protocol
from dataclasses import dataclass, field
from tenacity import retry, stop_after_attempt, wait_fixed, retry_if_exception_type
class ModelProvider(Protocol):
    def chat(self, messages: List[Dict[str, str]]) -> str:
        ...
class OllamaProvider:
    def __init__(self, model_name: str, timeout: int):
        try:
            import ollama
            self.client = ollama
        except ImportError:
            raise ImportError('请安装 ollama 库：pip install ollama')
        self.model_name = model_name
        self.timeout = timeout
    def chat(self, messages: List[Dict[str, str]]) -> str:
        response = self.client.chat(model=self.model_name, messages=messages, timeout=self.timeout)
        return response['message']['content'].strip()
class OpenAICompatibleProvider:
    def __init__(self, api_key: str, base_url: str, model_name: str, timeout: int):
        if not api_key:
            raise ValueError('API Key 不能为空')
        from openai import OpenAI
        self.client = OpenAI(api_key=api_key, base_url=base_url)
        self.model_name = model_name
    def chat(self, messages: List[Dict[str, str]]) -> str:
        r = self.client.chat.completions.create(model=self.model_name, messages=messages, temperature=0.7)
        return r.choices[0].message.content
@dataclass
class AppConfig:
    provider: str = os.getenv('LLM_PROVIDER', 'ollama')
    ollama_model: str = os.getenv('OLLAMA_MODEL', 'qwen:7b')
    cloud_model: str = os.getenv('CLOUD_MODEL', 'deepseek-chat')
CONFIG = AppConfig()
class PluginManager:
    def __init__(self):
        self.plugins = {}
    def weather_sim(self):
        return '🔌 今日天气：晴，适合出海捕鱼'
    def price_checker(self):
        return '🔌 今日海鲜参考价：25~38 元/斤'
class KnowledgeBaseManager:
    def __init__(self, p: Path):
        self.path = p
        self.data = {'market_rules':['清明前皮皮虾最肥'], 'recipes':[]}
    def build_prompt(self):
        return '你是茶海虾王，海鲜市场老江湖。'
class ChaohaiXiawangAgent:
    def __init__(self):
        self.kbm = KnowledgeBaseManager(Path('knowledge_base.json'))
        self.pm = PluginManager()
    def chat(self, text):
        if '天气' in text: return self.pm.weather_sim()
        if '价格' in text: return self.pm.price_checker()
        if '记住' in text: return '🧠 已记住！'
        return '🦐 虾王在此！有何吩咐？'
def main():
    bot = ChaohaiXiawangAgent()
    print('=== 🦐 茶海虾王 V3.1 启动成功 ===')
    while True:
        i = input('你：')
        if i in ['exit','quit','退出']: break
        print('虾王：', bot.chat(i))
if __name__ == '__main__':
    main()
