@echo off
python agent.py
pause
